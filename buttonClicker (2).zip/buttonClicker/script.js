function remove(element){
    element.remove();
}

function textChange(element){
    element.innerText ="Logout";
}

function showAlert(){
    alert("Ninja was liked!");
}

function playVid(element){
    element.play();
}

function pauseVid(element){
    element.pause();
}