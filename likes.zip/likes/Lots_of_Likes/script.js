function addLikes(element){
    var likesCounter=document.querySelector(element);
    var count=parseInt(likesCounter.innerText);
    count++;
    likesCounter.innerText=count;
    console.log(count)
}


