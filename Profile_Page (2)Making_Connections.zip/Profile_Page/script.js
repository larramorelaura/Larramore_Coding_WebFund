function addConnection(element){
    var connection=document.querySelector(element);
    var count=parseInt(connection.innerText);
    count++;
    connection.innerText=count;
    console.log(count);
}

function decreaseRequest(element){
    var request=document.querySelector(element);
    var requestCount=parseInt(request.innerText);
    requestCount--;
    request.innerText=requestCount;
    console.log(requestCount);
}

function hide(element){
    var hideThis=document.querySelector(element);
    hideThis.remove();
}

function editProfile(element){
    var profileName=document.querySelector(element);
    profileName.innerText='James Allen';
}